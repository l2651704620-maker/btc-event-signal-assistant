# BTC Event Signal Assistant V2

Android 原生 Kotlin + Jetpack Compose 项目源码。

## V2 功能
- BTCUSDT 1m / 5m 行情历史初始化
- Binance 公共 WebSocket 实时 K 线
- EMA9/EMA21、RSI14、MACD 动量和成交量过滤
- 只提示 BTC 的候选最强方向（买涨 / 买跌 / 观望）
- Android 前台服务：切换应用后持续监控
- WebSocket 断线后指数退避重连（2 秒起，最长 60 秒）
- Android 通知：候选信号提醒
- 本地保存最近 200 条信号
- 手动标记赢 / 输 / 跳过，并统计手动记录胜率
- 单笔 50 USDT、10 分钟作为交易参考参数
- 不登录币安、不保存 API 密钥、不自动下单

## 编译运行
1. 在电脑安装 Android Studio 稳定版、JDK 17 和 Android SDK 35。
2. 解压 ZIP，在 Android Studio 打开项目根目录。
3. 等待 Gradle Sync；连接 Android 手机，开启开发者选项和 USB 调试。
4. 点击 Run 安装。
5. 首次运行允许通知；点击“开始后台监控”。
6. 如果手机系统有电池优化限制，请将本应用设为允许后台运行/不受电池优化限制。

## 行情接口
REST:
`https://api.binance.com/api/v3/klines?symbol=BTCUSDT&interval=1m&limit=200`
WebSocket:
`wss://stream.binance.com:9443/stream?streams=btcusdt@kline_1m/btcusdt@kline_5m`

官方开发文档：
- https://developers.binance.com/docs/binance-spot-api-docs/web-socket-streams
- https://developers.binance.com/docs/binance-spot-api-docs/rest-api/market-data-endpoints

## 重要限制
- 数据源是 Binance BTCUSDT 现货市场，不是币安事件合约专用报价、指数或结算价。
- Binance Event Contracts 的 API 下单能力受官方产品限制；本项目不尝试调用普通合约 API 代替事件合约 API。
- 应用不会自动提交订单。请在官方币安 App 中自行核对事件合约方向、期限、价格和潜在损失。
- “规则评分”不是胜率；手动标记胜率依赖用户输入，不能证明策略有效。
- 本版本没有历史回测模块。历史回测若使用现货 K 线，只能作为方向命中率代理，不能等同事件合约收益或实际胜率。
- 前台服务在用户停止、系统强制停止、重启手机等情况下会停止；需重新启动监控。
- 本项目源码尚未在你的设备上实际编译或验收，首次打开后需由 Android Studio 完成 Gradle 构建。

## 风险
10 分钟短周期波动具有高度不确定性。50 USDT 是参考投入金额，不代表风险上限；具体损失取决于事件合约规则和成交报价。请先模拟测试。
