package com.example.btceventsignal

import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class BinanceFeed {
    private val client = OkHttpClient.Builder().pingInterval(20, TimeUnit.SECONDS).build()
    suspend fun load(interval: String): List<Candle> = withContext(Dispatchers.IO) {
        val url = "https://api.binance.com/api/v3/klines?symbol=BTCUSDT&interval=$interval&limit=200"
        client.newCall(Request.Builder().url(url).build()).execute().use { r ->
            check(r.isSuccessful) { "Binance HTTP ${r.code}" }
            val a = JSONArray(r.body?.string() ?: "[]")
            (0 until a.length()).map { i ->
                val x = a.getJSONArray(i)
                Candle(x.getLong(0), x.getString(1).toDouble(), x.getString(2).toDouble(),
                    x.getString(3).toDouble(), x.getString(4).toDouble(), x.getString(5).toDouble(),
                    i < a.length() - 1)
            }
        }
    }

    suspend fun stream(
        onStatus: (String) -> Unit,
        onCandle: (String, Candle) -> Unit
    ) {
        val done = CompletableDeferred<Unit>()
        val url = "wss://stream.binance.com:9443/stream?streams=btcusdt@kline_1m/btcusdt@kline_5m"
        val ws = client.newWebSocket(Request.Builder().url(url).build(), object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) { onStatus("行情已连接") }
            override fun onMessage(webSocket: WebSocket, text: String) {
                try {
                    val root = JSONObject(text)
                    val k = root.getJSONObject("data").getJSONObject("k")
                    val interval = k.getString("i")
                    onCandle(interval, Candle(k.getLong("t"), k.getString("o").toDouble(),
                        k.getString("h").toDouble(), k.getString("l").toDouble(),
                        k.getString("c").toDouble(), k.getString("v").toDouble(), k.getBoolean("x")))
                } catch (_: Exception) { onStatus("行情解析异常") }
            }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                onStatus("连接断开：${t.message ?: "网络异常"}")
                done.complete(Unit)
            }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                onStatus("连接关闭，准备重连")
                done.complete(Unit)
            }
        })
        done.await()
        ws.cancel()
    }
}
