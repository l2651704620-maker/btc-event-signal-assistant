package com.example.btceventsignal

object SignalEngine {
    fun evaluate(oneMinute: List<Candle>, fiveMinute: List<Candle>): Signal? {
        val a = oneMinute.filter { it.closed }.takeLast(120)
        val b = fiveMinute.filter { it.closed }.takeLast(120)
        if (a.size < 35 || b.size < 35) return null
        val c1 = a.map { it.close }
        val c5 = b.map { it.close }
        val e9 = ema(c1, 9); val e21 = ema(c1, 21)
        val e9f = ema(c5, 9); val e21f = ema(c5, 21)
        val r = rsi(c1, 14)
        val h0 = macdHistogram(c1)
        val h1 = macdHistogram(c1.dropLast(1))
        val avgVol = a.takeLast(21).dropLast(1).map { it.volume }.average()
        val volOk = avgVol > 0 && a.last().volume > avgVol * 1.05
        var up = 0; var down = 0
        val ur = mutableListOf<String>(); val dr = mutableListOf<String>()
        if (e9 > e21) { up += 2; ur += "1分钟 EMA9 高于 EMA21" }
        if (e9 < e21) { down += 2; dr += "1分钟 EMA9 低于 EMA21" }
        if (e9f > e21f) { up += 2; ur += "5分钟趋势向上" }
        if (e9f < e21f) { down += 2; dr += "5分钟趋势向下" }
        if (r in 52.0..68.0) { up++; ur += "RSI 动量偏强 (${r.toInt()})" }
        if (r in 32.0..48.0) { down++; dr += "RSI 动量偏弱 (${r.toInt()})" }
        if (h0 > 0 && h0 > h1) { up++; ur += "MACD 柱体增强" }
        if (h0 < 0 && h0 < h1) { down++; dr += "MACD 柱体走弱" }
        if (volOk && up > down) { up++; ur += "成交量高于近期均量" }
        if (volOk && down > up) { down++; dr += "成交量高于近期均量" }
        val dir = when {
            up >= 5 && up - down >= 3 -> Direction.UP
            down >= 5 && down - up >= 3 -> Direction.DOWN
            else -> Direction.WAIT
        }
        return Signal(dir, maxOf(up, down).coerceAtMost(8), a.last().close,
            when (dir) { Direction.UP -> ur; Direction.DOWN -> dr; Direction.WAIT -> listOf("多空条件不一致，暂不提示") },
            a.last().openTime)
    }

    private fun ema(v: List<Double>, n: Int): Double {
        val k = 2.0 / (n + 1)
        return v.drop(1).fold(v.first()) { x, y -> y * k + x * (1 - k) }
    }
    private fun rsi(v: List<Double>, n: Int): Double {
        val d = v.zipWithNext { x, y -> y - x }.takeLast(n)
        val gain = d.filter { it > 0 }.sum() / n
        val loss = -d.filter { it < 0 }.sum() / n
        if (loss == 0.0) return 100.0
        val rs = gain / loss
        return 100.0 - 100.0 / (1.0 + rs)
    }
    private fun macdHistogram(v: List<Double>): Double {
        if (v.size < 35) return 0.0
        val line = v.indices.map { i ->
            val p = v.take(i + 1)
            if (p.size < 26) 0.0 else ema(p, 12) - ema(p, 26)
        }
        val valid = line.drop(25)
        if (valid.size < 9) return 0.0
        return valid.last() - ema(valid, 9)
    }
}
