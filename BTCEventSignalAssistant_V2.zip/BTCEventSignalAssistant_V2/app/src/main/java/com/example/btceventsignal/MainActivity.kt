package com.example.btceventsignal

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val history by lazy { HistoryStore(this) }
    private var status by mutableStateOf("尚未启动")
    private var price by mutableStateOf<Double?>(null)
    private var direction by mutableStateOf("WAIT")
    private var score by mutableIntStateOf(0)
    private var reasons by mutableStateOf(listOf<String>())
    private val askNotification = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != MonitorService.ACTION_UPDATE) return
            status = intent.getStringExtra("status") ?: status
            val p = intent.getDoubleExtra("price", -1.0)
            if (p > 0) price = p
            direction = intent.getStringExtra("direction") ?: "WAIT"
            score = intent.getIntExtra("score", 0)
            reasons = intent.getStringArrayListExtra("reasons") ?: emptyList()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            askNotification.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent {
            MaterialTheme {
                Screen(
                    status, price, direction, score, reasons, history.read(),
                    onStart = {
                        ContextCompat.startForegroundService(this, Intent(this, MonitorService::class.java))
                    },
                    onStop = {
                        startService(Intent(this, MonitorService::class.java).setAction(MonitorService.ACTION_STOP))
                        status = "已请求停止监控"
                    },
                    onOutcome = { outcome -> history.setLatestOutcome(outcome) }
                )
            }
        }
    }

    @Suppress("DEPRECATION")
    override fun onStart() {
        super.onStart()
        val f = IntentFilter(MonitorService.ACTION_UPDATE)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, RECEIVER_NOT_EXPORTED)
        else registerReceiver(receiver, f)
    }
    override fun onStop() {
        try { unregisterReceiver(receiver) } catch (_: Exception) { }
        super.onStop()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun Screen(
    status: String, price: Double?, direction: String, score: Int, reasons: List<String>,
    records: List<SignalRecord>, onStart: () -> Unit, onStop: () -> Unit, onOutcome: (String) -> Unit
) {
    Scaffold(topBar = { TopAppBar(title = { Text("BTC 事件合约助手 V2") }) }) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("BTC / USDT", style = MaterialTheme.typography.headlineMedium)
                        Text(price?.let { "参考现货价：${"%,.2f".format(it)} USDT" } ?: "等待行情…")
                        Text("状态：$status")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = onStart) { Text("开始后台监控") }
                            OutlinedButton(onClick = onStop) { Text("停止") }
                        }
                    }
                }
            }
            item {
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("最强候选信号", style = MaterialTheme.typography.titleLarge)
                        Text(when(direction) {
                            "UP" -> "候选方向：买涨"
                            "DOWN" -> "候选方向：买跌"
                            else -> "观望"
                        }, style = MaterialTheme.typography.headlineSmall)
                        Text("规则评分：$score / 8（不是胜率）")
                        reasons.forEach { Text("• $it") }
                        Text("参考金额：50 USDT；目标期限：10 分钟")
                        Text("本应用不下单。请在币安官方 App 核对事件合约报价、方向及期限。")
                    }
                }
            }
            item {
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("信号结果标记", style = MaterialTheme.typography.titleMedium)
                        Text("你可以在交易结算后手动标记最近一条信号，统计结果不代表自动核验。")
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { onOutcome("赢") }) { Text("标记赢") }
                            OutlinedButton(onClick = { onOutcome("输") }) { Text("标记输") }
                            OutlinedButton(onClick = { onOutcome("跳过") }) { Text("跳过") }
                        }
                    }
                }
            }
            item {
                val decided = records.count { it.outcome == "赢" || it.outcome == "输" }
                val wins = records.count { it.outcome == "赢" }
                val rate = if (decided == 0) "暂无数据" else "%.1f%%".format(wins * 100.0 / decided)
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("记录统计", style = MaterialTheme.typography.titleMedium)
                        Text("历史信号：${records.size} 条")
                        Text("已标记结果：$decided 条")
                        Text("手动记录胜率：$rate")
                    }
                }
            }
            item { Text("最近信号记录", style = MaterialTheme.typography.titleMedium) }
            items(records.take(30)) { r ->
                Card {
                    Column(Modifier.padding(12.dp)) {
                        Text("${r.direction} · 评分 ${r.score}/8 · ${"%,.2f".format(r.price)} USDT")
                        Text(SimpleDateFormat("MM-dd HH:mm:ss", Locale.getDefault()).format(Date(r.time)))
                        Text("结果：${r.outcome}")
                    }
                }
            }
            item {
                Text(
                    "后台监控依赖 Android 前台服务。部分手机厂商的省电策略可能仍会限制网络；请允许通知并将应用设为不受电池优化限制。策略信号不是保证盈利的预测。",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.secondary
                )
            }
        }
    }
}
