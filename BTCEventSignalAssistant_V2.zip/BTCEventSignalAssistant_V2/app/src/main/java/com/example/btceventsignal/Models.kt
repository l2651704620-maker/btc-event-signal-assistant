package com.example.btceventsignal

data class Candle(
    val openTime: Long, val open: Double, val high: Double,
    val low: Double, val close: Double, val volume: Double, val closed: Boolean
)

enum class Direction { UP, DOWN, WAIT }

data class Signal(
    val direction: Direction,
    val score: Int,
    val price: Double,
    val reasons: List<String>,
    val candleTime: Long,
    val createdAt: Long = System.currentTimeMillis()
)

data class SignalRecord(
    val direction: String,
    val score: Int,
    val price: Double,
    val time: Long,
    val outcome: String = "待记录"
)
